<?php
$host = "localhost";
$user = "root";
$pass = "";
$bd = "montielmusicadaw2";
?>