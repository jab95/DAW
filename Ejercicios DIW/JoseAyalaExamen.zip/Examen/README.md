[overLIB](http://www.bosrup.com/web/overlib/ "OverLIB")
=======

Javascript popup library by Erik Bosrup

Note that his [license](http://www.bosrup.com/web/overlib/?License) 
requires you to keep his copyright notice at the top of the overlib.js.

This is a place to store fixes and updates added by the community.    
It is based on version 4.21 which seems to be what most people are using.
